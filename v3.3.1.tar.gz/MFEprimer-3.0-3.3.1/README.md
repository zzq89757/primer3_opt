This site is only for distributing binary files.

## Online server
* v4: [https://m4.igenetech.com/](https://m4.igenetech.com/)
* v3: [https://mfeprimer3.igenetech.com/](https://mfeprimer3.igenetech.com/)

## Doc
* [https://www.mfeprimer.com](https://www.mfeprimer.com)

## Download 
* [https://github.com/quwubin/MFEprimer-3.0/releases](https://github.com/quwubin/MFEprimer-3.0/releases)
